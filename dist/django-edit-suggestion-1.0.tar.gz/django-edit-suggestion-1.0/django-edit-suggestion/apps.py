from django.apps import AppConfig


class EditSuggestionConfig(AppConfig):
    name = 'edit_suggestion'
